public class Donkey extends PackAnimal {
    private boolean isObedient;

    public Donkey(String name, String color, Double weight, String address, int carryingCapacity, boolean isObedient) {
        super(name, color, weight, address, carryingCapacity);
        this.isObedient = isObedient;
    }

    public boolean isObedient() {
        return isObedient;
    }

    public void setObedient(boolean obedient) {
        isObedient = obedient;
    }

    public void bray() {
        System.out.println("Осел " + name + " иа-кает");
    }

    @Override
    public String toString() {
        return super.toString() + " and I am " + (isObedient ? "obedient" : "disobedient");
    }
}