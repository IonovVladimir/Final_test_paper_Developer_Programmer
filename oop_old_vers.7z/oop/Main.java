public class Main {
    public static void main(String[] args) {

        System.out.println("Тестирование:");
        /*
        Animal lion= new Animal("Лев","white", 0.3, "Africa");

        System.out.println(lion.toString());

        lion.eat(2F);

        Animal dog= new Pet("Simon", "red", 30.0, "California", "Jon");
        System.out.println(dog.toString());
        dog.eat(3F);

        Animal Rick= new Dog("Rick", "Black", 30.0, "California", "Jon", "bulldog");
        System.out.println(Rick.toString());

        Horse myHorse = new Horse("Буцефал", "вороной", 600.0, "Конюшня", 150, "Арабская");
        myHorse.neigh();
        System.out.println(myHorse);

        Camel myCamel = new Camel("Бактриан", "рыжий", 800.0, "Пустыня", 300, 2);
        myCamel.spit();
        System.out.println(myCamel);

        Donkey myDonkey = new Donkey("Иа", "серый", 300.0, "Ферма", 80, true);
        myDonkey.bray();
        System.out.println(myDonkey);


         */

        //Аннотация и пример кода

        /*
        Класс Animal - базовый класс, описывающий общее поведение животных.
        Класс Pet - субкласс Animal, описывающий домашних животных.
        Классы Dog, Cat, Hamster - субклассы Pet, описывающие конкретные виды домашних животных.
        Класс PackAnimal - субкласс Animal, описывающий животных, используемых для переноса грузов.
        Классы Horse, Camel, Donkey - субклассы PackAnimal, описывающие конкретные виды животных,
        используемых для переноса грузов.
         */

        // Создаю домашних животных
        Dog myDog = new Dog("Бобик", "черный", 10.0, "Москва", "Иван", "Овчарка");
        Cat myCat = new Cat("Мурка", "серый", 5.0, "Санкт-Петербург", "Мария", true);
        Hamster myHamster = new Hamster("Хрюша", "серый", 0.2, "Санкт-Петербург", "Мария", 3);

        // Использую методы домашних животных
        myDog.bark();
        myCat.meow();
        myHamster.runInWheel();

        System.out.println(myDog);
        System.out.println(myCat);
        System.out.println(myHamster);

        // Создаю животных для переноса грузов
        Horse myHorse = new Horse("Буцефал", "вороной", 600.0, "Конюшня", 150, "Арабская");
        Camel myCamel = new Camel("Жора", "рыжий", 800.0, "Пустыня", 300, 2);
        Donkey myDonkey = new Donkey("Иа", "серый", 300.0, "Ферма", 80, true);

        // Использую методы животных для переноса грузов
        myHorse.neigh();
        myCamel.spit();
        myDonkey.bray();

        System.out.println(myHorse);
        System.out.println(myCamel);
        System.out.println(myDonkey);
    }
}