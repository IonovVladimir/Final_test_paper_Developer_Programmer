public class PackAnimal extends Animal {
    private int carryingCapacity;

    public PackAnimal(String name, String color, Double weight, String address, int carryingCapacity) {
        super(name, color, weight, address);
        this.carryingCapacity = carryingCapacity;
    }

    public int getCarryingCapacity() {
        return carryingCapacity;
    }

    public void setCarryingCapacity(int carryingCapacity) {
        this.carryingCapacity = carryingCapacity;
    }

    public void carryLoad() {
        System.out.println(name + " несет груз весом " + carryingCapacity + " кг");
    }

    @Override
    public String toString() {
        return super.toString() + " and my carrying capacity is " + carryingCapacity + " kg";
    }
}