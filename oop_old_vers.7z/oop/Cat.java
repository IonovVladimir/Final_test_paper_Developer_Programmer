public class Cat extends Pet {
    private boolean isPlayful;

    public Cat(String name, String color, Double weight, String address, String owner, boolean isPlayful) {
        super(name, color, weight, address, owner);
        this.isPlayful = isPlayful;
    }

    public boolean isPlayful() {
        return isPlayful;
    }

    public void setPlayful(boolean playful) {
        isPlayful = playful;
    }

    public void meow() {
        System.out.println("Кошка " + name + " мяукает");
    }

    @Override
    public String toString() {
        return super.toString() + " and I am " + (isPlayful ? "playful" : "not playful");
    }
}