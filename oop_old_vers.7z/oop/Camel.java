public class Camel extends PackAnimal {
    private int humpsCount;

    public Camel(String name, String color, Double weight, String address, int carryingCapacity, int humpsCount) {
        super(name, color, weight, address, carryingCapacity);
        this.humpsCount = humpsCount;
    }

    public int getHumpsCount() {
        return humpsCount;
    }

    public void setHumpsCount(int humpsCount) {
        this.humpsCount = humpsCount;
    }

    public void spit() {
        System.out.println("Верблюд " + name + " плюется");
    }

    @Override
    public String toString() {
        return super.toString() + " and I have " + humpsCount + " humps";
    }
}