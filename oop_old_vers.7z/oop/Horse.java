public class Horse extends PackAnimal {
    private String breed;

    public Horse(String name, String color, Double weight, String address, int carryingCapacity, String breed) {
        super(name, color, weight, address, carryingCapacity);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void neigh() {
        System.out.println("Лошадь " + name + " ржет");
    }

    @Override
    public String toString() {
        return super.toString() + " and I am a " + breed;
    }
}