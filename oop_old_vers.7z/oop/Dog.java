public class Dog extends Pet {
    private String breed;

    public Dog(String name, String color, Double weight, String address, String owner, String breed) {
        super(name, color, weight, address, owner);
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void bark() {
        System.out.println("Собака " + name + " лает");
    }

    @Override
    public String toString() {
        return super.toString() + " and I am a " + breed;
    }
}