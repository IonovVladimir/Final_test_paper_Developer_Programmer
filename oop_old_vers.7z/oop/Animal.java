public class Animal {
    protected String name;
    protected String color;
    protected Double weight;
    protected String address;

    public Animal(String name, String color, Double weight, String address) {
        this.name = name;
        this.color = color;
        this.weight = weight;
        this.address = address;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    protected void eat(float food){
        weight+=food;
        System.out.println(" Животное "+name+" накормлено. Новый вес составляет: "+weight);
    }

    @Override
    public String toString(){
        return "I am "+this.getClass().getName()+" ( my address "+ address+")";
    }


}
